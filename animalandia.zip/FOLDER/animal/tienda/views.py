from django.shortcuts import render



def tienda(request):
     context = {}
     return render(request, 'tienda/tienda.html', context)

def carrito(request):
     context = {}
     return render(request, 'tienda/carrito.html', context)

def registro_c(request):
      context = {}
      return render(request, 'tienda/registro_c.html', context)