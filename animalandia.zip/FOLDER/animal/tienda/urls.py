from django.urls import path

from . import views

urlpatterns = [
        #Leave as empty string for base url
	path('', views.tienda, name="tienda"),
	path('carrito/', views.carrito, name="carrito"),
	path('registro_c/', views.registro_c, name="registro_c"),


]